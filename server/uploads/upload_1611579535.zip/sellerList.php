<?php
error_reporting(E_ALL);
$devID = "f6596691-9b24-4afd-a70f-b56a322b7f26"; //– Your Developer ID
$appID = "MohdSuhe-MWS-PRD-c92e00ec4-6225999b"; //– Your Application ID
$certID = "PRD-92e00ec439ab-6af4-4422-a679-e90f"; //– Your Certificate ID
$serverUrl = "https://api.ebay.com/ws/api.dll"; //– Sandbox or Production URL
//Use this URL for sandbox mode: https://api.sandbox.ebay.com/ws/api.dll
//Use this URL for production mode: https://api.ebay.com/ws/api.dll
$userToken = "AgAAAA**AQAAAA**aAAAAA**n1mgXQ**nY+sHZ2PrBmdj6wVnY+sEZ2PrA2dj6AAmYukD5GDoAydj6x9nY+seQ**QyAGAA**AAMAAA**1iZzc13m3wjeGHHFoU3E7eRan6whrWDYfr43h4bZMeyrj4ZCCqi44rg+mbySDhy3SI9mrJ07x5ilhk5o5l8zu9sc6hklxetCwPD1M473BOsjJZhTNmD35bysS5T8tVVPhKfntxtabw2cYXEH7Pa9xH4/KuW5wGL5eluitegALzYXAVpVlv2eKzafCaK4sAnwvOWH2+1Gnn9VTsAXDdd6xloJ8u3zNvltFR1iKV8vhmGOidqRWdGr6agCyjblNPEa77t6wypNqF1I/HfTq3QUhlnF9uTIvAnUf9H1m2aJ9IuZ2TK8xkD2i3lNRTpxR6kSXZo5KV0hvQpFiOmvC6EUs3kyNiNhZhXP3yNpFKPwbGKZoR5lKApq2xfMtqhl1z2Fvs+6gm4s99R0Emwo+/QbGZgShgy7dw2L26kWZmb0IOzYA16rDAeWRoz6kD3X/t+zK3ip20Ky1gVSiGJKz8/hoSG/CNYSwJy4p+WWf1oOuuknkk6IFP/R0n+uPVcJD3k3NJOJ1MiqqXDSxk4ij13L55voVKk5V5mP0JOd9u8+MyBlSVZ3gFFXKCQRXXLFBjd7FUmGoQyrnRSYeTLw8bDTMbizKSNpN4L0zOhEkxAlF+L0Axhd8G1LSfdVOCCvii7qY3C4I+L9inIZ1AocQWneygzV+/fm8ka4rjQ03gTjGzIzXicEbAlgVjbZCaZqHYU5pswh+CApndRYf8HJ+UVFVd+enp/Toc6cN5x/wqOiOeHVg49qO8vA1XkTJ6s3ELar"; //– the Authentication Token representing the eBay user who is making the call.

$username  = "customdesigned"; // - Use  developer's account's user name , if you use sandbox mode otherwise merchant's account's username.

//SiteID must also be set in the Request's XML
//SiteID = 0  (US) – UK = 3, Canada = 2, Australia = 15, ….
//SiteID Indicates the eBay site to associate the call with

$siteID = 0;
$verb = "GetSellerList"; //API call name
$StartTimeFrom = "2019-02-30T21:59:59.005Z";
$StartTimeTo = "2019-05-26T21:59:59.005Z";
$EntriesPerPage = "100";
$version = "825";

$headers = array (
//Regulates versioning of the XML interface for the API
"X-EBAY-API-COMPATIBILITY-LEVEL: " . $version,

//set the keys
"X-EBAY-API-DEV-NAME: " . $devID,
"X-EBAY-API-APP-NAME: " . $appID,
"X-EBAY-API-CERT-NAME: " . $certID,

//the name of the call we are requesting
"X-EBAY-API-CALL-NAME: " . $verb,

"X-EBAY-API-SITEID: " . $siteID,
);

//Build the request Xml string
/*
$requestXmlBody = "<?xml version='1.0' encoding='utf-8'?>
<GetSellerListRequest xmlns='urn:ebay:apis:eBLBaseComponents'>
<RequesterCredentials>
<eBayAuthToken>".$userToken."</eBayAuthToken>
</RequesterCredentials>
<UserID>".$username."</UserID>
<GranularityLevel>CustomCode</GranularityLevel>
<StartTimeFrom>".$StartTimeFrom."</StartTimeFrom>
<StartTimeTo>".$StartTimeTo."</StartTimeTo>
<Pagination>
<EntriesPerPage>".$EntriesPerPage."</EntriesPerPage>
</Pagination>
</GetSellerListRequest>";
*/

 $requestXmlBody = "<?xml version='1.0' encoding='utf-8'?>
 <GetSellerListRequest xmlns='urn:ebay:apis:eBLBaseComponents'>  
 <RequesterCredentials>
<eBayAuthToken>".$userToken."</eBayAuthToken>
</RequesterCredentials>
<UserID>".$username."</UserID>  
 <ErrorLanguage>en_US</ErrorLanguage>
 <WarningLevel>High</WarningLevel>     
 <GranularityLevel>Coarse</GranularityLevel> 
   <StartTimeFrom>2019-03-21T06:38:48.420Z</StartTimeFrom> 
   <StartTimeTo>2019-07-15T06:38:48.420Z</StartTimeTo> 
  <IncludeWatchCount>true</IncludeWatchCount> 
  <Pagination> 
    <EntriesPerPage>10</EntriesPerPage> 
  </Pagination> 
</GetSellerListRequest>";



//build eBay headers using variables passed via constructor

//initialise a CURL session
$connection = curl_init();
//set the server we are using (could be Sandbox or Production server)
curl_setopt($connection, CURLOPT_URL, $serverUrl);

//stop CURL from verifying the peer's certificate
curl_setopt($connection, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($connection, CURLOPT_SSL_VERIFYHOST, 0);

//set the headers using the array of headers
curl_setopt($connection, CURLOPT_HTTPHEADER, $headers);

//set method as POST
curl_setopt($connection, CURLOPT_POST, 1);

//set the XML body of the request
curl_setopt($connection, CURLOPT_POSTFIELDS, $requestXmlBody);

//set it to return the transfer as a string from curl_exec
curl_setopt($connection, CURLOPT_RETURNTRANSFER, 1);

//Send the Request
$response = curl_exec($connection);

//close the connection
curl_close($connection);

if(stristr($response, "HTTP 404") || $response == "")
die('Error sending request');

$resultXmlData = simplexml_load_string($response);

echo "<pre>";
print_r($resultXmlData);
?>